#!/bin/sh
#SBATCH -n 1
#SBATCH -c 22
#SBATCH -p amd-shared
#SBATCH --qos=amd-shared
#SBATCH -w "c[3114,3116,3119-3120]"
#SBATCH --mem=60G
#SBATCH --mail-type=END
#SBATCH --mail-user=pau.balart@ibe.upf-csic.es
#SBATCH -o CSP_phylo_btrim_slurm.%j.out
#SBATCH -e CSP_phylo_btrim_slurm.%j.err
#SBATCH --time=2-0:0

module load cesga/2018
module load gcccore/6.4.0 mafft/7.407-with-extensions

mafft --auto --maxiterate 1000 --thread 22 CSP_B_trim_phylo.fasta > CSP_B_trim_phylo.aln

module load cesga/2018
module load gcccore/6.4.0 trimal/1.4.1

trimal -in CSP_B_trim_phylo.aln -gt 0.4 -out CSP_B_trim_phylo_trimmed_gt0.4.fasta

module load cesga/2018
module load gcccore/6.4.0 fasttree/2.1.11

FastTree -lg CSP_B_trim_phylo_trimmed_gt0.4.fasta > CSP_B_trim_phylo_trimmed_gt0.4_guide.treefile

module load cesga/2020
module load iq-tree/2.1.3

iqtree2 -s CSP_B_trim_phylo_trimmed_gt0.4.fasta -m LG+C20+F+G -ft CSP_B_trim_phylo_trimmed_gt0.4_guide.treefile -B 1000 -T 22
