#!/bin/sh
#SBATCH -n 1
#SBATCH -c 22
#SBATCH -p cl-intel-shared
#SBATCH --qos=cl-intel-shared
#SBATCH -w "c[3201-3202,3208-3212,3214-3220]"
#SBATCH --mem=60G
#SBATCH --mail-type=END
#SBATCH --mail-user=pau.balart@ibe.upf-csic.es
#SBATCH -o GR_phylo_btrim_slurm.%j.out
#SBATCH -e GR_phylo_btrim_slurm.%j.err
#SBATCH --time=2-0:0

module load cesga/2018
module load gcccore/6.4.0 mafft/7.407-with-extensions

mafft --auto --maxiterate 1000 --thread 22 GR_B_trimed_phylo_DMEL.fasta > GR_B_trimed_phylo_DMEL.aln

module load cesga/2018
module load gcccore/6.4.0 trimal/1.4.1

trimal -in GR_B_trimed_phylo_DMEL.aln -gt 0.4 -out GR_B_trimed_phylo_trimmed_gt0.4_DMEL.fasta

module load cesga/2018
module load gcccore/6.4.0 fasttree/2.1.11

FastTree -lg GR_B_trimed_phylo_trimmed_gt0.4_DMEL.fasta > GR_B_trimed_phylo_trimmed_gt0.4_guide.treefile

module load cesga/2020
module load iq-tree/2.1.3

iqtree2 -s GR_B_trimed_phylo_trimmed_gt0.4_DMEL.fasta -m LG+C20+F+G -ft GR_B_trimed_phylo_trimmed_gt0.4_guide.treefile -B 1000 -T 22
