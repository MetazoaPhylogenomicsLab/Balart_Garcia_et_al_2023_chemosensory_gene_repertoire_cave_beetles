#!/bin/sh
#SBATCH -n 1
#SBATCH -c 22
#SBATCH -p amd-shared
#SBATCH --qos=amd-shared
#SBATCH --mem=60G
#SBATCH --mail-type=END
#SBATCH --mail-user=pau.balart@ibe.upf-csic.es
#SBATCH -o OR_phylo_btrim_slurm.%j.out
#SBATCH -e OR_phylo_btrim_slurm.%j.err
#SBATCH --time=2-0:0

module load cesga/2018
module load gcccore/6.4.0 mafft/7.407-with-extensions

mafft --auto --maxiterate 1000 --thread 22 OR_Btrimed_10percent_filter.fasta > OR_B_trimed_phylo.aln

module load cesga/2018
module load gcccore/6.4.0 trimal/1.4.1

trimal -in OR_B_trimed_phylo.aln -gt 0.4 -out OR_B_trimed_phylo_trimmed_gt0.4.fasta

module load cesga/2018
module load gcccore/6.4.0 fasttree/2.1.11

FastTree -lg OR_B_trimed_phylo_trimmed_gt0.4.fasta > OR_B_trimed_phylo_trimmed_gt0.4_guide.treefile

module load cesga/2020
module load iq-tree/2.1.3

iqtree2 -s OR_B_trimed_phylo_trimmed_gt0.4.fasta -m LG+C20+F+G -ft OR_B_trimed_phylo_trimmed_gt0.4_guide.treefile -B 1000 -T 22
